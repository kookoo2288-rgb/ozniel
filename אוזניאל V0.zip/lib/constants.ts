export const PHONE_DISPLAY = '058-444-3326'
export const WHATSAPP_BASE = 'https://wa.me/972584443326'
export const WHATSAPP_MESSAGE =
  'שלום, אשמח לקבל פרטים על פתרונות השמיעה לילדים'
export const WHATSAPP_LINK = `${WHATSAPP_BASE}?text=${encodeURIComponent(
  WHATSAPP_MESSAGE,
)}`
export const LEAD_EMAIL = 'yon228@gmail.com'
