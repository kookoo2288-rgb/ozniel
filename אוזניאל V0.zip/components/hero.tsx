import Image from 'next/image'
import { ShieldCheck, Home, Heart } from 'lucide-react'

const TRUST_BADGES = [
  { icon: Home, label: 'שימוש ביתי ונוח' },
  { icon: ShieldCheck, label: 'פתרון לא פולשני' },
  { icon: Heart, label: 'מותאם לילדים' },
]

export function Hero() {
  return (
    <section
      id="top"
      className="relative overflow-hidden bg-gradient-to-b from-brand-light/60 via-background to-background pt-28 pb-16 md:pt-36 md:pb-24"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-24 top-24 h-72 w-72 rounded-full bg-turquoise-soft blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-16 -top-10 h-72 w-72 rounded-full bg-brand-light blur-3xl"
      />

      <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-4 md:grid-cols-2 md:gap-8 md:px-6">
        <div className="animate-fade-up text-center md:text-right">
          <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-turquoise/40 bg-turquoise-soft/70 px-4 py-1.5 text-sm font-semibold text-brand-dark">
            <span className="h-2 w-2 rounded-full bg-turquoise" />
            פתרון שמיעה ביתי לילדים
          </span>
          <h1 className="text-balance text-3xl font-extrabold leading-tight text-brand-dark md:text-5xl">
            {'נמאס לכם שהילד/ה עונה "מה?" על כל שאלה?'}
          </h1>
          <p className="mt-4 text-pretty text-lg font-semibold text-primary md:text-xl">
            פתרון ביתי חדשני לילדים עם נוזלים באוזניים וקשיי שמיעה
          </p>
          <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            באוזניאל אנו מציעים פתרון חדשני ונוח לשימוש ביתי, שנועד לסייע באוורור
            האוזן התיכונה ובהתמודדות עם נוזלים ולחץ באוזניים.
          </p>

          <ul className="mt-8 flex flex-wrap justify-center gap-x-6 gap-y-3 md:justify-start">
            {TRUST_BADGES.map((badge) => (
              <li
                key={badge.label}
                className="flex items-center gap-2 text-sm font-medium text-foreground/70"
              >
                <badge.icon className="h-4 w-4 text-turquoise" aria-hidden="true" />
                {badge.label}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative">
          <div className="animate-fade-up relative mx-auto max-w-md">
            <div className="relative overflow-hidden rounded-[2rem] border border-border bg-card shadow-xl shadow-primary/10">
              <Image
                src="/images/child-listening.png"
                alt="ילד מחייך ומקשיב בקשב רב"
                width={640}
                height={720}
                priority
                className="h-full w-full object-cover"
              />
            </div>
            <div className="animate-float-soft absolute -bottom-8 -left-6 w-40 overflow-hidden rounded-2xl border border-border bg-card p-3 shadow-xl md:w-48">
              <Image
                src="/images/product-device.png"
                alt="המכשיר הביתי של אוזניאל לאוורור האוזן התיכונה"
                width={240}
                height={200}
                className="h-auto w-full object-contain"
              />
              <p className="mt-1 text-center text-xs font-semibold text-brand-dark">
                המכשיר הביתי
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
