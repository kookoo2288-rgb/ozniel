import { UserRound, Zap, Lightbulb, Smile, FileText } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const ITEMS = [
  { icon: UserRound, title: 'שירות אישי' },
  { icon: Zap, title: 'מענה מהיר' },
  { icon: Lightbulb, title: 'פתרונות חדשניים' },
  { icon: Smile, title: 'דגש על נוחות הילד' },
  { icon: FileText, title: 'מידע ברור להורים' },
]

export function TrustSection() {
  return (
    <section className="bg-background py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <Reveal className="mx-auto max-w-3xl text-center">
          <h2 className="text-balance text-2xl font-extrabold leading-tight text-brand-dark md:text-4xl">
            באוזניאל אנחנו מאמינים ששמיעה טובה מתחילה בפתרון הנכון
          </h2>
        </Reveal>

        <div className="mx-auto mt-12 grid max-w-4xl grid-cols-2 gap-4 md:grid-cols-5">
          {ITEMS.map((item, i) => (
            <Reveal
              key={item.title}
              delay={i * 80}
              className="flex flex-col items-center gap-3 rounded-2xl border border-border bg-card p-5 text-center shadow-sm"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-turquoise-soft text-primary">
                <item.icon className="h-6 w-6" aria-hidden="true" />
              </span>
              <span className="text-sm font-bold text-brand-dark">
                {item.title}
              </span>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
