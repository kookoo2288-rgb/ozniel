import { Ear, Droplets, Volume2, BookOpen } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const ITEMS = [
  { icon: Ear, title: 'שמיעה פחות טובה', desc: 'ירידה ביכולת לשמוע צלילים חלשים' },
  { icon: Droplets, title: 'נוזלים באוזן התיכונה', desc: 'הצטברות נוזלים מאחורי עור התוף' },
  { icon: Volume2, title: 'תחושת אטימות ולחץ', desc: 'הרגשה של אוזן סתומה ולחוצה' },
  { icon: BookOpen, title: 'קושי להקשיב ולהתרכז', desc: 'השפעה על הקשב בגן, בכיתה ובבית' },
]

export function ProblemSection() {
  return (
    <section className="bg-background py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-2xl font-extrabold text-brand-dark md:text-4xl">
            נוזלים באוזניים יכולים להשפיע על השמיעה
          </h2>
          <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            נוזלים באוזן התיכונה הם תופעה נפוצה אצל ילדים ועלולים לגרום לתחושת
            אטימות, ירידה בשמיעה, קושי להקשיב ולעיתים להשפיע על ההתנהלות היומיומית
            של הילד.
          </p>
        </Reveal>

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {ITEMS.map((item, i) => (
            <Reveal
              key={item.title}
              delay={i * 100}
              className="flex flex-col items-center rounded-2xl border border-border bg-card p-6 text-center shadow-sm transition-shadow hover:shadow-md"
            >
              <span className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-turquoise-soft text-primary">
                <item.icon className="h-7 w-7" aria-hidden="true" />
              </span>
              <h3 className="text-base font-bold text-brand-dark">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {item.desc}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
