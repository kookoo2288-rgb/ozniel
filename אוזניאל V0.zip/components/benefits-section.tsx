import { Home, PillBottle, SlidersHorizontal, Baby, Wind, Waves } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const BENEFITS = [
  { icon: Home, title: 'נוח לשימוש בבית' },
  { icon: PillBottle, title: 'ללא צורך בתרופות' },
  { icon: SlidersHorizontal, title: 'פעולה פשוטה ומבוקרת' },
  { icon: Baby, title: 'מתאים לילדים בהתאם להנחיות' },
  { icon: Wind, title: 'עשוי לסייע באוורור האוזן התיכונה' },
  { icon: Waves, title: 'עשוי לסייע בהתמודדות עם נוזלים ולחץ באוזניים' },
]

export function BenefitsSection() {
  return (
    <section id="benefits" className="scroll-mt-24 bg-background py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-2xl font-extrabold text-brand-dark md:text-4xl">
            למה הורים בוחרים בפתרון הזה?
          </h2>
        </Reveal>

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {BENEFITS.map((benefit, i) => (
            <Reveal
              key={benefit.title}
              delay={(i % 3) * 100}
              className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-6 shadow-sm transition-all hover:-translate-y-1 hover:shadow-md"
            >
              <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-brand text-primary-foreground transition-transform group-hover:scale-105">
                <benefit.icon className="h-7 w-7" aria-hidden="true" />
              </span>
              <h3 className="text-base font-bold leading-snug text-brand-dark md:text-lg">
                {benefit.title}
              </h3>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
