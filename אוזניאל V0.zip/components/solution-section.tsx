import { Wind, ArrowLeft, Ear } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const FLOW = [
  { label: 'אף', desc: 'זרימת אוויר מבוקרת נכנסת דרך הנחיר' },
  { label: 'חצוצרת השמע', desc: 'האוויר מסייע בפתיחת החצוצרה' },
  { label: 'אוזן תיכונה', desc: 'אוורור החלל שמאחורי עור התוף' },
]

export function SolutionSection() {
  return (
    <section
      id="solution"
      className="scroll-mt-24 bg-gradient-to-b from-background to-brand-light/40 py-16 md:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="mb-3 inline-flex items-center gap-2 rounded-full bg-turquoise-soft px-4 py-1.5 text-sm font-semibold text-brand-dark">
            <Wind className="h-4 w-4" aria-hidden="true" />
            הפתרון
          </span>
          <h2 className="text-balance text-2xl font-extrabold text-brand-dark md:text-4xl">
            פתרון חדשני שניתן להשתמש בו בבית
          </h2>
          <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            המכשיר מיועד ליצור זרימת אוויר מבוקרת דרך האף בזמן בליעה, במטרה לסייע
            בפתיחת חצוצרת השמע ולאוורור האוזן התיכונה.
          </p>
        </Reveal>

        <Reveal
          delay={150}
          className="mx-auto mt-12 max-w-4xl rounded-3xl border border-border bg-card p-6 shadow-lg md:p-10"
        >
          <div className="flex flex-col items-stretch gap-4 md:flex-row md:items-center md:justify-between">
            {FLOW.map((step, i) => (
              <div key={step.label} className="contents">
                <div className="flex flex-1 flex-col items-center rounded-2xl bg-secondary/60 p-5 text-center">
                  <span className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground text-lg font-bold">
                    {i + 1}
                  </span>
                  <h3 className="text-base font-bold text-brand-dark md:text-lg">
                    {step.label}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {step.desc}
                  </p>
                </div>
                {i < FLOW.length - 1 && (
                  <ArrowLeft
                    className="mx-auto h-6 w-6 -rotate-90 text-turquoise md:rotate-0"
                    aria-hidden="true"
                  />
                )}
              </div>
            ))}
          </div>

          <div className="mt-8 flex items-center justify-center gap-3 rounded-2xl bg-turquoise-soft/60 px-5 py-4 text-center">
            <Ear className="h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
            <p className="text-sm font-semibold text-brand-dark md:text-base">
              שימוש פשוט, קצר ונוח — בהתאם להנחיות השימוש.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
