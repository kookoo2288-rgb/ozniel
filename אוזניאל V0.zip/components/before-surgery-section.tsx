import { HeartHandshake, Info } from 'lucide-react'
import { Reveal } from '@/components/reveal'

export function BeforeSurgerySection() {
  return (
    <section className="bg-gradient-to-b from-brand-light/40 to-background py-16 md:py-24">
      <div className="mx-auto max-w-4xl px-4 md:px-6">
        <Reveal className="rounded-3xl border border-border bg-card p-8 shadow-lg md:p-12">
          <span className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-turquoise-soft text-primary">
            <HeartHandshake className="h-7 w-7" aria-hidden="true" />
          </span>
          <h2 className="text-balance text-2xl font-extrabold leading-tight text-brand-dark md:text-4xl">
            יש ילדים שניתן לעזור להם לפני שמגיעים לפתרונות פולשניים
          </h2>
          <p className="mt-5 text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            כשילד מתמודד עם נוזלים באוזניים וירידה בשמיעה, קיימות גישות שונות
            להתמודדות עם הבעיה. הפתרון שלנו נועד לספק אפשרות ביתית ולא פולשנית
            שעשויה לסייע בחלק מהמקרים.
          </p>
          <div className="mt-6 flex items-start gap-3 rounded-2xl border border-turquoise/30 bg-turquoise-soft/50 p-5">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
            <p className="text-sm font-semibold leading-relaxed text-brand-dark md:text-base">
              לא לכל ילד הפתרון מתאים, ולכן חשוב להתייעץ עם רופא או איש מקצוע
              מתאים.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
