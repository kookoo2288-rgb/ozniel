'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'

const FAQS = [
  {
    q: 'מה גורם לנוזלים באוזניים?',
    a: 'נוזלים באוזן התיכונה נובעים לרוב מתפקוד לא מיטבי של חצוצרת השמע, לעיתים בעקבות הצטננויות, אלרגיות או דלקות. הנוזל מצטבר בחלל שמאחורי עור התוף ועלול להישאר שם לתקופה.',
  },
  {
    q: 'מהם התסמינים של נוזלים באוזניים?',
    a: 'התסמינים הנפוצים כוללים תחושת אטימות באוזן, ירידה בשמיעה, לחץ, ולעיתים קושי להקשיב ולהתרכז. אצל ילדים הדבר עשוי להתבטא בצורך להגביר את עוצמת הקול או בקושי להתרכז.',
  },
  {
    q: 'האם המכשיר מתאים לכל ילד?',
    a: 'לא לכל ילד הפתרון מתאים. ההתאמה תלויה במצב הספציפי, ולכן חשוב להתייעץ עם רופא או איש מקצוע רפואי לפני השימוש.',
  },
  {
    q: 'כל כמה זמן משתמשים במכשיר?',
    a: 'השימוש נעשה בהתאם להנחיות השימוש של המכשיר ובהתאם להמלצת איש המקצוע. מדובר בשימוש קצר ונוח שניתן לבצע בבית.',
  },
  {
    q: 'האם צריך להתייעץ עם רופא?',
    a: 'כן. אנו ממליצים להתייעץ עם רופא או איש מקצוע רפואי מתאים לפני תחילת השימוש, כדי לבחון האם הפתרון עשוי להתאים לילד.',
  },
  {
    q: 'האם המכשיר מחליף ניתוח כפתורים?',
    a: 'לא. המכשיר אינו תחליף מובטח לניתוח ואינו מתאים לכל ילד. מטרתו לספק אפשרות לא פולשנית שעשויה לסייע במקרים מתאימים. יש להתייעץ עם רופא או איש מקצוע רפואי לפני השימוש.',
  },
]

export function FaqSection() {
  const [open, setOpen] = useState<number | null>(0)

  return (
    <section id="faq" className="scroll-mt-24 bg-background py-16 md:py-24">
      <div className="mx-auto max-w-3xl px-4 md:px-6">
        <h2 className="text-balance text-center text-2xl font-extrabold text-brand-dark md:text-4xl">
          שאלות נפוצות
        </h2>

        <div className="mt-10 flex flex-col gap-3">
          {FAQS.map((faq, i) => {
            const isOpen = open === i
            return (
              <div
                key={faq.q}
                className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
              >
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-right"
                  aria-expanded={isOpen}
                >
                  <span className="text-base font-bold text-brand-dark md:text-lg">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={cn(
                      'h-5 w-5 shrink-0 text-primary transition-transform duration-300',
                      isOpen && 'rotate-180',
                    )}
                    aria-hidden="true"
                  />
                </button>
                <div
                  className={cn(
                    'grid transition-all duration-300 ease-out',
                    isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]',
                  )}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-sm leading-relaxed text-muted-foreground md:text-base">
                      {faq.a}
                    </p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
