'use client'

import { useActionState } from 'react'
import { useFormStatus } from 'react-dom'
import { MessageCircle, Phone, Send, CheckCircle2 } from 'lucide-react'
import { submitLead, type LeadState } from '@/app/actions/submit-lead'
import { PHONE_DISPLAY, WHATSAPP_LINK } from '@/lib/constants'

const initialState: LeadState = { status: 'idle', message: '' }

function SubmitButton() {
  const { pending } = useFormStatus()
  return (
    <button
      type="submit"
      disabled={pending}
      className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-bold text-primary-foreground shadow-lg shadow-primary/20 transition-transform hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-70"
    >
      <Send className="h-5 w-5" aria-hidden="true" />
      {pending ? 'שולח...' : 'שלחו לי פרטים'}
    </button>
  )
}

const FIELDS = [
  { name: 'fullName', label: 'שם מלא', type: 'text', required: true, placeholder: 'ישראל ישראלי' },
  { name: 'phone', label: 'טלפון', type: 'tel', required: true, placeholder: '050-0000000' },
  { name: 'email', label: 'אימייל', type: 'email', required: false, placeholder: 'name@example.com' },
  { name: 'childAge', label: 'גיל הילד', type: 'text', required: false, placeholder: 'לדוגמה: 5' },
]

export function ContactSection() {
  const [state, formAction] = useActionState(submitLead, initialState)

  return (
    <section id="contact" className="scroll-mt-24 bg-gradient-to-b from-brand-light/40 to-background py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-2xl font-extrabold text-brand-dark md:text-4xl">
            רוצים לקבל פרטים נוספים?
          </h2>
          <p className="mt-3 text-base text-muted-foreground md:text-lg">
            השאירו פרטים ונחזור אליכם, או דברו איתנו ישירות בוואטסאפ.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-5">
          {/* Form */}
          <div className="rounded-3xl border border-border bg-card p-6 shadow-lg md:p-8 lg:col-span-3">
            {state.status === 'success' ? (
              <div className="flex min-h-[24rem] flex-col items-center justify-center text-center">
                <span className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-turquoise-soft text-turquoise">
                  <CheckCircle2 className="h-9 w-9" aria-hidden="true" />
                </span>
                <p className="text-balance text-lg font-bold text-brand-dark md:text-xl">
                  {state.message}
                </p>
              </div>
            ) : (
              <form action={formAction} className="flex flex-col gap-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  {FIELDS.map((field) => (
                    <div key={field.name} className="flex flex-col gap-1.5">
                      <label
                        htmlFor={field.name}
                        className="text-sm font-semibold text-brand-dark"
                      >
                        {field.label}
                        {field.required && (
                          <span className="text-primary"> *</span>
                        )}
                      </label>
                      <input
                        id={field.name}
                        name={field.name}
                        type={field.type}
                        required={field.required}
                        placeholder={field.placeholder}
                        className="rounded-xl border border-border bg-background px-4 py-2.5 text-base text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                  ))}
                </div>

                <div className="flex flex-col gap-1.5">
                  <label
                    htmlFor="message"
                    className="text-sm font-semibold text-brand-dark"
                  >
                    הודעה
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={4}
                    placeholder="ספרו לנו קצת על מה שהילד מתמודד איתו..."
                    className="resize-none rounded-xl border border-border bg-background px-4 py-2.5 text-base text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                {state.status === 'error' && (
                  <p
                    role="alert"
                    className="rounded-xl bg-destructive/10 px-4 py-3 text-sm font-semibold text-destructive"
                  >
                    {state.message}
                  </p>
                )}

                <SubmitButton />
                <p className="text-center text-xs text-muted-foreground">
                  בשליחת הטופס אתם מאשרים שניצור עמכם קשר בנוגע לפנייתכם.
                </p>
              </form>
            )}
          </div>

          {/* WhatsApp / Direct contact */}
          <div className="flex flex-col gap-4 lg:col-span-2">
            <div className="flex flex-1 flex-col justify-center rounded-3xl bg-gradient-to-br from-primary to-brand-dark p-8 text-primary-foreground shadow-lg">
              <span className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-turquoise text-brand-dark">
                <MessageCircle className="h-7 w-7" aria-hidden="true" />
              </span>
              <h3 className="text-xl font-bold">מעדיפים לדבר איתנו ישירות?</h3>
              <p className="mt-2 text-sm leading-relaxed text-primary-foreground/80">
                שלחו לנו הודעה בוואטסאפ ונשמח לענות על כל שאלה ולבדוק התאמה.
              </p>
              <a
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-turquoise px-6 py-3.5 text-base font-bold text-brand-dark transition-transform hover:scale-[1.03]"
              >
                <MessageCircle className="h-5 w-5" aria-hidden="true" />
                דברו איתנו בוואטסאפ
              </a>
              <a
                href={`tel:${PHONE_DISPLAY.replace(/-/g, '')}`}
                className="mt-3 inline-flex items-center justify-center gap-2 text-sm font-semibold text-primary-foreground/90 hover:text-primary-foreground"
              >
                <Phone className="h-4 w-4" aria-hidden="true" />
                {PHONE_DISPLAY}
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
