import Image from 'next/image'
import { Check } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const ITEMS = [
  'ילדים עם נוזלים באוזן התיכונה',
  'ילדים עם תחושת אטימות באוזניים',
  'ילדים עם ירידה בשמיעה הקשורה לנוזלים',
  'הורים שמחפשים פתרון ביתי ולא פולשני',
]

export function SuitabilitySection() {
  return (
    <section className="bg-background py-16 md:py-24">
      <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 md:grid-cols-2 md:px-6">
        <Reveal className="order-2 md:order-1">
          <h2 className="text-balance text-2xl font-extrabold text-brand-dark md:text-4xl">
            האם הפתרון יכול להתאים לילד שלכם?
          </h2>
          <ul className="mt-8 flex flex-col gap-4">
            {ITEMS.map((item) => (
              <li
                key={item}
                className="flex items-center gap-3 rounded-2xl border border-border bg-card px-5 py-4 shadow-sm"
              >
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-turquoise text-brand-dark">
                  <Check className="h-5 w-5" aria-hidden="true" />
                </span>
                <span className="text-base font-medium text-foreground">
                  {item}
                </span>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            className="mt-8 inline-flex items-center justify-center rounded-full bg-primary px-8 py-3.5 text-base font-bold text-primary-foreground shadow-lg shadow-primary/20 transition-transform hover:scale-[1.03]"
          >
            בדקו התאמה
          </a>
        </Reveal>

        <Reveal delay={150} className="order-1 md:order-2">
          <div className="relative mx-auto max-w-md overflow-hidden rounded-[2rem] border border-border bg-turquoise-soft/40 shadow-xl">
            <Image
              src="/images/product-device.png"
              alt="המכשיר הביתי של אוזניאל"
              width={560}
              height={520}
              className="h-full w-full object-contain p-8"
            />
          </div>
        </Reveal>
      </div>
    </section>
  )
}
