import { MessageCircle, Send } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { WHATSAPP_LINK } from '@/lib/constants'

export function CtaBanner() {
  return (
    <section className="bg-background py-16 md:py-20">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <Reveal className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-dark via-primary to-brand p-8 text-center text-primary-foreground shadow-xl md:p-14">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -left-16 -top-16 h-56 w-56 rounded-full bg-turquoise/20 blur-3xl"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -bottom-16 -right-16 h-56 w-56 rounded-full bg-turquoise/20 blur-3xl"
          />
          <div className="relative">
            <h2 className="text-balance text-2xl font-extrabold md:text-4xl">
              לא חייבים להישאר עם השאלות
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-pretty text-base leading-relaxed text-primary-foreground/85 md:text-lg">
              אם הילד שלכם מתמודד עם נוזלים באוזניים או ירידה בשמיעה, נשמח להסביר
              לכם על הפתרון ולבדוק האם הוא עשוי להתאים.
            </p>
            <div className="mt-8 flex flex-col items-stretch justify-center gap-3 sm:flex-row">
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 rounded-full bg-primary-foreground px-7 py-3.5 text-base font-bold text-primary shadow-lg transition-transform hover:scale-[1.03]"
              >
                <Send className="h-5 w-5" aria-hidden="true" />
                שלחו פרטים
              </a>
              <a
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-full bg-turquoise px-7 py-3.5 text-base font-bold text-brand-dark shadow-lg transition-transform hover:scale-[1.03]"
              >
                <MessageCircle className="h-5 w-5" aria-hidden="true" />
                דברו איתנו בוואטסאפ
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
