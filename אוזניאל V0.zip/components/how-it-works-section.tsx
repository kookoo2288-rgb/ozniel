import { Plug, Power, Soup } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const STEPS = [
  { icon: Plug, title: 'מצמידים את המתאם לנחיר', desc: 'הצמדה עדינה ונוחה של מתאם האף' },
  { icon: Power, title: 'מפעילים את המכשיר', desc: 'הפעלה פשוטה ליצירת זרימת אוויר מבוקרת' },
  { icon: Soup, title: 'בולעים בזמן הפעולה', desc: 'הבליעה מסייעת בפתיחת חצוצרת השמע' },
]

export function HowItWorksSection() {
  return (
    <section
      id="how"
      className="scroll-mt-24 bg-gradient-to-b from-background to-brand-light/40 py-16 md:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-2xl font-extrabold text-brand-dark md:text-4xl">
            איך זה עובד?
          </h2>
          <p className="mt-4 text-base text-muted-foreground md:text-lg">
            שלושה שלבים פשוטים לשימוש נוח בבית
          </p>
        </Reveal>

        <div className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-3">
          {STEPS.map((step, i) => (
            <Reveal
              key={step.title}
              delay={i * 120}
              className="relative flex flex-col items-center rounded-3xl border border-border bg-card p-8 text-center shadow-sm"
            >
              <span className="absolute -top-4 flex h-9 w-9 items-center justify-center rounded-full bg-turquoise text-sm font-bold text-brand-dark shadow-md">
                {i + 1}
              </span>
              <span className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-brand text-primary-foreground">
                <step.icon className="h-8 w-8" aria-hidden="true" />
              </span>
              <h3 className="text-lg font-bold text-brand-dark">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {step.desc}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
