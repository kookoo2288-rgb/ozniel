import { Reveal } from '@/components/reveal'

export function ResearchSection() {
  return (
    <section className="bg-gradient-to-br from-brand-dark to-primary py-16 text-primary-foreground md:py-24">
      <div className="mx-auto max-w-4xl px-4 text-center md:px-6">
        <Reveal>
          <p className="text-sm font-semibold uppercase tracking-wide text-turquoise-soft">
            נתונים ומחקר
          </p>
          <div className="mt-6 flex flex-col items-center">
            <span className="bg-gradient-to-b from-white to-turquoise-soft bg-clip-text text-7xl font-black leading-none text-transparent md:text-8xl">
              86%
            </span>
            <p className="mt-4 text-balance text-xl font-bold md:text-2xl">
              שיפור משמעותי בשמיעה בעקבות השימוש
            </p>
          </div>
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-sm leading-relaxed text-primary-foreground/70">
            הנתון מבוסס על מחקר קליני שפורסם בנושא השימוש במכשיר לטיפול בילדים עם
            נוזלים באוזניים (OME). התוצאות עשויות להשתנות בין מטופלים.
          </p>
        </Reveal>
      </div>
    </section>
  )
}
