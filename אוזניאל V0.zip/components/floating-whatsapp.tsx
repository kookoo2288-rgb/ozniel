import { MessageCircle } from 'lucide-react'
import { WHATSAPP_LINK } from '@/lib/constants'

export function FloatingWhatsApp() {
  return (
    <a
      href={WHATSAPP_LINK}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="דברו איתנו בוואטסאפ"
      className="animate-float-soft fixed bottom-5 left-5 z-50 flex items-center gap-2 rounded-full bg-turquoise px-4 py-3 font-bold text-brand-dark shadow-xl shadow-turquoise/30 transition-transform hover:scale-105 md:bottom-6 md:left-6"
    >
      <MessageCircle className="h-6 w-6" aria-hidden="true" />
      <span className="hidden text-sm sm:inline">דברו איתנו בוואטסאפ</span>
    </a>
  )
}
