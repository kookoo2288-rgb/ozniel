import { Ear } from 'lucide-react'
import { PHONE_DISPLAY } from '@/lib/constants'

const LINKS = [
  { href: '#top', label: 'דף הבית' },
  { href: '#solution', label: 'אודות' },
  { href: '#faq', label: 'שאלות נפוצות' },
  { href: '#contact', label: 'צור קשר' },
  { href: '#', label: 'מדיניות פרטיות' },
  { href: '#', label: 'תנאי שימוש' },
]

export function SiteFooter() {
  return (
    <footer className="bg-brand-dark text-primary-foreground">
      <div className="mx-auto max-w-6xl px-4 py-14 md:px-6">
        <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <div className="flex items-center gap-2">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-turquoise text-brand-dark">
                <Ear className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="flex flex-col leading-tight">
                <span className="text-lg font-extrabold">אוזניאל</span>
                <span className="text-[11px] font-medium text-primary-foreground/60">
                  פתרונות שמיעה
                </span>
              </span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-primary-foreground/70">
              פתרונות ביתיים חדשניים לשיפור השמיעה אצל ילדים ולהתמודדות עם נוזלים
              ולחץ באוזן התיכונה.
            </p>
            <p className="mt-4 text-sm font-semibold text-turquoise-soft">
              טלפון: {PHONE_DISPLAY}
            </p>
          </div>

          <nav aria-label="ניווט תחתון">
            <ul className="grid grid-cols-2 gap-x-10 gap-y-3">
              {LINKS.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-primary-foreground/80 transition-colors hover:text-turquoise-soft"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <div className="mt-10 border-t border-primary-foreground/15 pt-6">
          <p className="text-xs leading-relaxed text-primary-foreground/55">
            המידע באתר אינו מהווה תחליף לייעוץ רפואי. התאמת המוצר והשימוש בו
            צריכים להיעשות בהתאם להנחיות היצרן ובהתייעצות עם איש מקצוע רפואי
            במידת הצורך.
          </p>
          <p className="mt-4 text-xs text-primary-foreground/45">
            © {new Date().getFullYear()} אוזניאל - פתרונות שמיעה. כל הזכויות
            שמורות.
          </p>
        </div>
      </div>
    </footer>
  )
}
